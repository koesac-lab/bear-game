const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.join(__dirname, '..');
const date = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(new Date());
const old = new Date(Date.parse(date + 'T12:00:00Z') - 40 * 86400000).toISOString().slice(0, 10);
const types = { 'visual-a':'Visual Calm', 'visual-b':'Visual Calm', 'story-a':'Micro-Story',
  'touch-a':'Interactive Moment', 'thought-a':'Wisdom Drop', 'draft-a':'Micro-Story' };
const schedule = `daily_slots:
  - visual-calm
  - micro-story
  - interactive-moment
  - wisdom-drop
rules:
  no_repeat_within_days: 90
  debut_new_first: true
pinned:
shelf:
  window_days: 30
`;
function fixture(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'moodscroll-p1-'));
  t.after(() => fs.rmSync(dir, { recursive:true, force:true }));
  fs.mkdirSync(path.join(dir, 'site', 'experiences'), { recursive:true });
  fs.copyFileSync(path.join(root, 'build.cjs'), path.join(dir, 'build.cjs'));
  fs.copyFileSync(path.join(root, 'site', 'index.html'), path.join(dir, 'site', 'index.html'));
  fs.writeFileSync(path.join(dir, 'schedule.yaml'), schedule);
  fs.writeFileSync(path.join(dir, 'publish-log.json'), JSON.stringify({days:{},firstSeen:{'draft-a':old,'story-a':old}}));
  for (const [slug, type] of Object.entries(types)) {
    const status = slug === 'draft-a' ? 'draft' : 'live';
    fs.writeFileSync(path.join(dir, 'site', 'experiences', slug + '.html'),
      `<html><head><title>${slug}</title><meta name="description" content="test"><meta name="moodscroll:type" content="${type}"><meta name="moodscroll:status" content="${status}"></head></html>`);
  }
  return dir;
}
function run(dir, ...args) { return spawnSync(process.execPath, ['build.cjs', ...args], { cwd:dir, encoding:'utf8' }); }
function manifest(dir) { return JSON.parse(fs.readFileSync(path.join(dir, 'dist/current/shelf.json'))); }
function ledger(dir) { return JSON.parse(fs.readFileSync(path.join(dir, 'publish-log.json'))); }
function setPins(dir, slugs) {
  const file = path.join(dir, 'schedule.yaml');
  fs.writeFileSync(file, fs.readFileSync(file, 'utf8').replace('pinned:', `pinned:\n  "${date}": [${slugs.join(', ')}]`));
}
test('pins occupy slots and reject conflicting, missing and draft pins', t => {
  const dir = fixture(t);
  setPins(dir, ['visual-a']);
  assert.equal(run(dir).status, 0);
  assert.deepEqual(manifest(dir).daily, ['visual-a.html','story-a.html','touch-a.html','thought-a.html']);
  const before = fs.readlinkSync(path.join(dir, 'dist/current'));
  const beforeLog = fs.readFileSync(path.join(dir, 'publish-log.json'), 'utf8');
  for (const pins of [['visual-a','visual-b'],['absent'],['draft-a']]) {
    fs.writeFileSync(path.join(dir, 'schedule.yaml'), schedule);
    setPins(dir, pins);
    assert.notEqual(run(dir).status, 0, pins.join(','));
    assert.equal(fs.readlinkSync(path.join(dir, 'dist/current')), before);
    assert.equal(fs.readFileSync(path.join(dir, 'publish-log.json'), 'utf8'), beforeLog);
  }
});
test('migration and late promotion use publication date; reruns are stable', t => {
  const dir = fixture(t);
  assert.equal(run(dir).status, 0);
  assert.equal(ledger(dir).firstPublished['story-a'], old);
  assert.equal(ledger(dir).firstPublished['draft-a'], undefined);
  const originalDaily = manifest(dir).daily;
  assert.equal(run(dir).status, 0);
  assert.deepEqual(manifest(dir).daily, originalDaily);
  const file = path.join(dir,'site/experiences/draft-a.html');
  fs.writeFileSync(file, fs.readFileSync(file,'utf8').replace('content="draft"','content="live"'));
  assert.equal(run(dir).status, 0);
  assert.equal(ledger(dir).firstPublished['draft-a'], date);
  assert.ok(manifest(dir).experiences.some(e => e.slug === 'draft-a' && e.added === date));
  const before = fs.readFileSync(path.join(dir, 'publish-log.json'), 'utf8');
  assert.equal(run(dir,'plan','--days','3').status, 0);
  assert.equal(fs.readFileSync(path.join(dir, 'publish-log.json'), 'utf8'), before);
});
test('failed build leaves active release and ledger intact', t => {
  const dir = fixture(t);
  assert.equal(run(dir).status, 0);
  const current = fs.readlinkSync(path.join(dir, 'dist/current'));
  const before = fs.readFileSync(path.join(dir, 'publish-log.json'), 'utf8');
  const index = path.join(dir,'site/index.html');
  fs.writeFileSync(index, fs.readFileSync(index,'utf8').replace('/*__SHELF__*/null','null'));
  assert.notEqual(run(dir).status, 0);
  assert.equal(fs.readlinkSync(path.join(dir, 'dist/current')), current);
  assert.equal(fs.readFileSync(path.join(dir, 'publish-log.json'), 'utf8'), before);
});
test('a missing required type fails instead of publishing a partial day', t => {
  const dir = fixture(t);
  fs.unlinkSync(path.join(dir, 'site/experiences/thought-a.html'));
  assert.notEqual(run(dir).status, 0);
  assert.equal(fs.existsSync(path.join(dir, 'dist/current')), false);
});

test('all four pins in reverse order still render in slot order', t => {
  const dir = fixture(t);
  setPins(dir, ['thought-a','touch-a','story-a','visual-a']);
  assert.equal(run(dir).status, 0);
  assert.deepEqual(manifest(dir).daily,
    ['visual-a.html','story-a.html','touch-a.html','thought-a.html']);
  const home = fs.readFileSync(path.join(dir,'dist/current/index.html'),'utf8');
  assert.ok(home.includes('window.SHELF = {'));
  assert.ok(!home.includes('/*__SHELF__*/null'));
  assert.equal(fs.existsSync(path.join(dir,'dist/current/publish-log.json')), false);
});
test('old flat dist stays intact during the first release build', t => {
  const dir = fixture(t);
  fs.mkdirSync(path.join(dir,'dist'));
  fs.writeFileSync(path.join(dir,'dist/index.html'),'legacy homepage');
  assert.equal(run(dir).status, 0);
  assert.equal(fs.readFileSync(path.join(dir,'dist/index.html'),'utf8'),'legacy homepage');
  assert.equal(fs.lstatSync(path.join(dir,'dist/current')).isSymbolicLink(), true);
});
test('active release restores a missing ledger before planning again', t => {
  const dir = fixture(t);
  assert.equal(run(dir).status, 0);
  const saved = ledger(dir);
  fs.writeFileSync(path.join(dir,'publish-log.json'),'{"days":{}}');
  assert.equal(run(dir).status, 0);
  assert.deepEqual(ledger(dir).days[date],saved.days[date]);
});
