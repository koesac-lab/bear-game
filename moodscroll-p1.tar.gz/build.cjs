// moodscroll.ing daily build — the containerized content planner.
// Resolves today's set from schedule.yaml + publish-log.json, ships the
// last 30 days of live content (plus greatest hits) to dist/, and bakes
// the manifest into index.html. Zero-dependency Node (>= 18).
// Deterministic: same plan + same ledger = same day.
//
//   node build.cjs                  full build → dist/
//   node build.cjs plan --days 30   dry-run the next N days (no writes)

const { readdirSync, readFileSync, writeFileSync, mkdirSync, mkdtempSync,
        copyFileSync, existsSync, rmSync, renameSync, symlinkSync, readlinkSync,
        lstatSync, unlinkSync, openSync, closeSync, statSync } = require('fs');
const { randomUUID } = require('crypto');
const { join, basename } = require('path');

const ROOT = __dirname;
const SITE_DIR = join(ROOT, 'site');
const EXP_DIR = join(SITE_DIR, 'experiences');
const DIST = join(ROOT, 'dist');
const LOG_PATH = join(ROOT, 'publish-log.json');
const SCHEDULE_PATH = join(ROOT, 'schedule.yaml');
const LEDGERS = join(ROOT, 'data', 'build-ledgers');

const TYPES = ['visual-calm', 'micro-story', 'interactive-moment', 'wisdom-drop'];
const TYPE_DISPLAY = {
  'visual-calm': 'Visual Calm',
  'micro-story': 'Micro-Story',
  'interactive-moment': 'Interactive Moment',
  'wisdom-drop': 'Wisdom Drop',
};
const TYPE_ALIASES = Object.fromEntries(
  Object.entries(TYPE_DISPLAY).flatMap(([k, d]) => [[k, k], [d, k], [d.toLowerCase(), k]]),
);

// ---------- schedule.yaml (minimal parser, same shape as the old one) ----------

function parseScalar(v) {
  v = v.trim().replace(/^["']|["']$/g, '');
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (/^\d+$/.test(v)) return parseInt(v, 10);
  return v;
}

function readSchedule(text) {
  const cfg = { publish_time: '06:00', daily_slots: [], rules: {}, pinned: {}, shelf: {} };
  let section = null;
  for (const raw of text.split('\n')) {
    const noComment = raw.replace(/(^|\s)#.*$/, '');
    if (!noComment.trim()) continue;
    const indent = noComment.length - noComment.trimStart().length;
    const line = noComment.trim();
    if (indent === 0) {
      const m = line.match(/^([a-z_]+):\s*(.*)$/);
      if (m) {
        const [, key, val] = m;
        if (val) { cfg[key] = parseScalar(val); section = null; }
        else section = key;
      }
    } else if (section === 'daily_slots') {
      const m = line.match(/^-\s*(.+)$/);
      if (m) cfg.daily_slots.push(m[1].trim());
    } else if (section === 'rules' || section === 'shelf' || section === 'premium') {
      const m = line.match(/^([a-z_]+):\s*(.+)$/);
      if (m) {
        // 'premium' is the legacy section name; fold it into shelf.
        const target = section === 'premium' ? 'shelf' : section;
        cfg[target][m[1]] = parseScalar(m[2]);
      }
    } else if (section === 'pinned') {
      const m = line.match(/^["']?(\d{4}-\d{2}-\d{2})["']?:\s*\[(.*)\]/);
      if (m) cfg.pinned[m[1]] = m[2].split(',').map(s => s.trim()).filter(Boolean);
    }
  }
  return cfg;
}

// ---------- publish-log.json (day ledger + firstSeen ledger) ----------

function readLog() {
  const log = existsSync(LOG_PATH) ? JSON.parse(readFileSync(LOG_PATH, 'utf8')) : {};
  log.days ||= {};
  log.firstSeen ||= {};
  log.firstPublished ||= {};
  return log;
}

function serialiseLog(log) {
  const sorted = (o) => Object.fromEntries(Object.entries(o).sort(([a], [b]) => a.localeCompare(b)));
  return JSON.stringify({ days: sorted(log.days), firstSeen: sorted(log.firstSeen),
    firstPublished: sorted(log.firstPublished), publicationLedgerVersion: log.publicationLedgerVersion }, null, 2) + '\n';
}

function writeLog(log) {
  const temp = `${LOG_PATH}.tmp-${randomUUID()}`;
  try {
    writeFileSync(temp, serialiseLog(log));
    renameSync(temp, LOG_PATH);
  } finally {
    if (existsSync(temp)) unlinkSync(temp);
  }
}

// A killed process can leave the symlink published before its ledger is saved.
// The active release carries the matching ledger for an idempotent recovery.
function recoverLog() {
  const current = join(DIST, 'current');
  let target;
  try { target = readlinkSync(current); }
  catch (err) { if (err.code === 'ENOENT') return; throw err; }
  const snapshot = join(LEDGERS, `${basename(target)}.json`);
  if (!existsSync(snapshot)) throw new Error(`Missing ledger for active release: ${target}`);
  const snapshotText = readFileSync(snapshot, 'utf8');
  if (!existsSync(LOG_PATH) || readFileSync(LOG_PATH, 'utf8') !== snapshotText)
    writeLog(JSON.parse(snapshotText));
}

// ---------- library ----------

function parseExperience(file, added) {
  const slug = basename(file, '.html');
  const html = readFileSync(join(EXP_DIR, file), 'utf8');
  const head = (html.match(/<head[\s\S]*?<\/head>/i) || [html.slice(0, 4000)])[0];
  const meta = (name) => {
    const m = head.match(new RegExp(`<meta[^>]+name=["']${name}["'][^>]*>`, 'i'));
    if (!m) return null;
    const c = m[0].match(/content=["']([^"']*)["']/i);
    return c ? c[1] : null;
  };
  const titleTag = (head.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1];
  const rawType = meta('moodscroll:type') || meta('moodscroll:category');
  const type = rawType ? (TYPE_ALIASES[rawType] || TYPE_ALIASES[rawType.toLowerCase()] || null) : null;
  const status = meta('moodscroll:status') || 'live';
  const tier = meta('moodscroll:tier') || 'free';
  const warnings = [];
  if (!titleTag || !titleTag.trim()) warnings.push('missing <title>');
  if (!meta('description')) warnings.push('missing meta description');
  if (!rawType) warnings.push('missing moodscroll:type');
  else if (!type) warnings.push(`unknown type "${rawType}"`);
  if (!['draft', 'ready', 'live', 'archived'].includes(status)) warnings.push(`unknown status "${status}"`);
  if (!['free', 'premium'].includes(tier)) warnings.push(`unknown tier "${tier}"`);
  return {
    slug, file,
    title: (titleTag || '').trim() || slug.replace(/-/g, ' '),
    description: meta('description') || '',
    type: type || 'moment',
    status, tier, added, warnings,
  };
}

// Discovery and first publication are different dates. Only the first migration
// treats already-live content's historic firstSeen as an approximate publish date.
function libraryFromDisk(log, date) {
  const files = existsSync(EXP_DIR) ? readdirSync(EXP_DIR).filter(f => f.endsWith('.html')) : [];
  const entries = files.map(f => parseExperience(f, log.firstSeen[basename(f, '.html')] || date));
  const migrating = log.publicationLedgerVersion !== 1;
  for (const e of entries) {
    log.firstSeen[e.slug] ||= date;
    if (e.status === 'live' && !log.firstPublished[e.slug])
      log.firstPublished[e.slug] = migrating ? log.firstSeen[e.slug] : date;
    e.added = log.firstPublished[e.slug] || null;
  }
  log.publicationLedgerVersion = 1;
  return entries;
}

// ---------- deterministic picking (from the old planner) ----------

function seededRandom(seed) {
  let h = 2166136261;
  for (const c of seed) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => {
    h = Math.imul(h ^ (h >>> 15), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };
}

function seededPick(items, seed) {
  const arr = [...items];
  const rnd = seededRandom(seed);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function todayLondon() {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(new Date());
}

function daysAgo(dateStr, n) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

function resolveDay(dateStr, cfg, library, log) {
  const slots = cfg.daily_slots;
  if (slots.length !== TYPES.length || new Set(slots).size !== TYPES.length ||
      slots.some(s => !TYPES.includes(s)))
    throw new Error(`Invalid daily_slots: expected one of each ${TYPES.join(', ')}`);
  const noRepeat = cfg.rules.no_repeat_within_days ?? 90;
  const cutoff = daysAgo(dateStr, noRepeat);
  const recentSlugs = new Set(Object.entries(log.days || {})
    .filter(([d]) => d >= cutoff && d < dateStr).flatMap(([, slugs]) => slugs));
  const publishedBefore = new Set(Object.entries(log.days || {})
    .filter(([d]) => d < dateStr).flatMap(([, slugs]) => slugs));
  const bySlug = new Map(library.map(e => [e.slug, e]));
  const pinned = new Map();
  for (const slug of cfg.pinned[dateStr] || []) {
    const entry = bySlug.get(slug);
    if (!entry || entry.status !== 'live') throw new Error(`${dateStr}: pinned slug ${slug} is not live or does not exist`);
    if (!slots.includes(entry.type)) throw new Error(`${dateStr}: pinned slug ${slug} has no configured slot`);
    if (pinned.has(entry.type)) throw new Error(`${dateStr}: two pins for ${entry.type}`);
    pinned.set(entry.type, entry);
  }
  const pickFor = (slot, taken) => {
    const inCategory = library.filter(e => e.status === 'live' && !taken.has(e.slug) && e.type === slot);
    const pool = inCategory.filter(e => !recentSlugs.has(e.slug));
    if (!pool.length && inCategory.length) {
      const lastSeen = {};
      for (const [d, slugs] of Object.entries(log.days || {})) {
        if (d >= dateStr) continue;
        for (const s of slugs) lastSeen[s] = d;
      }
      const sorted = [...inCategory].sort((a, b) => (lastSeen[a.slug] || '').localeCompare(lastSeen[b.slug] || ''));
      const oldest = sorted.filter(e => (lastSeen[e.slug] || '') === (lastSeen[sorted[0].slug] || ''));
      return seededPick(oldest, `${dateStr}:${slot}:lru`)[0];
    }
    if (!pool.length) return null;
    const fresh = cfg.rules.debut_new_first ? pool.filter(e => !publishedBefore.has(e.slug)) : [];
    return seededPick(fresh.length ? fresh : pool, `${dateStr}:${slot}`)[0];
  };
  // Preserve a published day on rerun, provided its four files are still live
  // and today's pins are satisfied. Never silently serve a removed/draft file.
  const previous = log.days[dateStr];
  if (previous && previous.length === slots.length) {
    const entries = previous.map(s => bySlug.get(s));
    if (entries.every((e, i) => e && e.status === 'live' && e.type === slots[i] &&
        (!pinned.has(slots[i]) || pinned.get(slots[i]).slug === e.slug))) return entries;
  }
  const taken = new Set([...pinned.values()].map(e => e.slug));
  return slots.map(slot => {
    const entry = pinned.get(slot) || pickFor(slot, taken);
    if (!entry) throw new Error(`${dateStr}: no live experience for ${slot}`);
    taken.add(entry.slug);
    return entry;
  });
}

// ---------- build ----------

function withBuildLock(action) {
  mkdirSync(DIST, { recursive: true });
  const lock = join(DIST, '.build-lock');
  try {
    if (existsSync(lock) && Date.now() - statSync(lock).mtimeMs > 6 * 60 * 60 * 1000) unlinkSync(lock);
    const fd = openSync(lock, 'wx');
    closeSync(fd);
  } catch (err) {
    if (err.code === 'EEXIST') throw new Error('A build is already running (dist/.build-lock exists)');
    throw err;
  }
  try { return action(); } finally { unlinkSync(lock); }
}

function pruneReleases(activeTarget, previousTarget) {
  const releases = join(DIST, 'releases');
  const keep = new Set([basename(activeTarget), previousTarget && basename(previousTarget)].filter(Boolean));
  const cutoff = Date.now() - 8 * 86400000;
  for (const name of readdirSync(releases)) {
    if (name.startsWith('.stage-') || keep.has(name)) continue;
    const file = join(releases, name);
    if (!name.startsWith('release-') || statSync(file).mtimeMs >= cutoff) continue;
    rmSync(file, { recursive: true, force: true });
    const ledger = join(LEDGERS, `${name}.json`);
    if (existsSync(ledger)) unlinkSync(ledger);
  }
}

function build() {
  return withBuildLock(() => {
    recoverLog();
    const cfg = readSchedule(readFileSync(SCHEDULE_PATH, 'utf8'));
    const log = readLog();
    const date = todayLondon();
    const libraryAll = libraryFromDisk(log, date);
    const warnCount = libraryAll.reduce((n, e) => n + e.warnings.length, 0);
    for (const e of libraryAll) for (const w of e.warnings) console.warn(`  warning ${e.file}: ${w}`);
    const library = libraryAll.filter(e => e.status === 'live');
    const todaysSet = resolveDay(date, cfg, library, log);

    const windowDays = cfg.shelf.window_days ?? cfg.shelf.trailing_days ?? 30;
    const cutoff = daysAgo(date, windowDays);
    const shelfSlugs = new Set(library.filter(e => e.added && e.added >= cutoff).map(e => e.slug));
    const hitsPath = join(ROOT, cfg.shelf.greatest_hits || 'greatest-hits.txt');
    const hits = existsSync(hitsPath)
      ? readFileSync(hitsPath, 'utf8').split('\n').map(s => s.trim()).filter(s => s && !s.startsWith('#'))
      : [];
    for (const s of hits) shelfSlugs.add(s);
    for (const e of todaysSet) shelfSlugs.add(e.slug);
    const shelf = library.filter(e => shelfSlugs.has(e.slug));
    const experiences = shelf.map(e => ({
      slug: e.slug, file: e.file, title: e.title, description: e.description,
      type: TYPE_DISPLAY[e.type], tier: e.tier, added: e.added,
      today: todaysSet.some(t => t.slug === e.slug), greatest_hit: hits.includes(e.slug),
    })).sort((a, b) => (b.added || '').localeCompare(a.added || ''));
    const manifest = { generated: new Date().toISOString(), date,
      daily: todaysSet.map(e => e.file), experiences };

    // Validate the source homepage before writing or switching anything.
    const sourceIndex = join(SITE_DIR, 'index.html');
    if (!existsSync(sourceIndex)) throw new Error('site/index.html is missing');
    const original = readFileSync(sourceIndex, 'utf8');
    const marker = '/*__SHELF__*/null';
    if (original.split(marker).length !== 2)
      throw new Error('site/index.html must contain the exact shelf marker once');
    const baked = original.replace(marker, () => JSON.stringify(manifest));
    const embedded = baked.match(/window\.SHELF\s*=\s*([\s\S]*?);\s*<\/script>/);
    if (!embedded || JSON.stringify(JSON.parse(embedded[1])) !== JSON.stringify(manifest))
      throw new Error('Baked homepage shelf is invalid');
    if (new Set(manifest.daily).size !== TYPES.length ||
        manifest.daily.some(f => !experiences.some(e => e.file === f)))
      throw new Error('Invalid daily manifest');

    const releases = join(DIST, 'releases');
    mkdirSync(releases, { recursive: true });
    const stage = mkdtempSync(join(releases, '.stage-'));
    const release = join(releases, `release-${date}-${randomUUID()}`);
    const current = join(DIST, 'current');
    const next = join(DIST, `.next-${randomUUID()}`);
    let oldTarget = null;
    try {
      mkdirSync(join(stage, 'experiences'));
      writeFileSync(join(stage, 'index.html'), baked);
      if (existsSync(join(SITE_DIR, 'about.html')))
        copyFileSync(join(SITE_DIR, 'about.html'), join(stage, 'about.html'));
      for (const e of shelf) copyFileSync(join(EXP_DIR, e.file), join(stage, 'experiences', e.file));
      writeFileSync(join(stage, 'shelf.json'), JSON.stringify(manifest, null, 2) + '\n');
      log.days[date] = todaysSet.map(e => e.slug);
      for (const file of manifest.daily)
        if (!existsSync(join(stage, 'experiences', file))) throw new Error(`Daily file missing: ${file}`);
      if (!Array.isArray(JSON.parse(readFileSync(join(stage, 'shelf.json'), 'utf8')).experiences))
        throw new Error('Staged shelf is invalid');
      mkdirSync(LEDGERS, { recursive: true });
      const ledgerPath = join(LEDGERS, `${basename(release)}.json`);
      writeFileSync(ledgerPath, serialiseLog(log));
      renameSync(stage, release);
      try { oldTarget = readlinkSync(current); }
      catch (err) { if (err.code !== 'ENOENT') throw err; }
      symlinkSync(join('releases', basename(release)), next);
      renameSync(next, current); // same filesystem; the mounted dist/ directory is untouched
      try { writeLog(log); }
      catch (err) {
        if (oldTarget) {
          symlinkSync(oldTarget, next);
          renameSync(next, current);
        } else unlinkSync(current);
        throw err;
      }
      console.log(`\nmoodscroll.ing build — ${date}`);
      console.log(`  library: ${libraryAll.length} file(s), ${library.length} live${warnCount ? ` (${warnCount} warnings)` : ''}`);
      console.log(`  today:   ${todaysSet.map(e => e.slug).join(', ')}`);
      console.log(`  dist:    ${shelf.length} experience(s) in ${basename(release)}`);
      try { pruneReleases(join('releases', basename(release)), oldTarget); }
      catch (err) { console.warn(`  warning: old release cleanup failed: ${err.message}`); }
    } finally {
      if (existsSync(next)) unlinkSync(next);
      if (existsSync(stage)) rmSync(stage, { recursive: true, force: true });
    }
  });
}

function plan(days) {
  const cfg = readSchedule(readFileSync(SCHEDULE_PATH, 'utf8'));
  const log = readLog();
  const date = todayLondon();
  const library = libraryFromDisk(log, date).filter(e => e.status === 'live');
  const simLog = JSON.parse(JSON.stringify(log));
  console.log(`moodscroll.ing plan — next ${days} day(s) from ${date}\n`);
  for (let i = 0; i < days; i++) {
    const d = new Date(date); d.setDate(d.getDate() + i);
    const dateStr = d.toISOString().slice(0, 10);
    const set = resolveDay(dateStr, cfg, library, simLog);
    simLog.days[dateStr] = set.map(e => e.slug);
    console.log(`${dateStr}  ${set.map(e => e.slug).join(', ') || '(empty)'}`);
  }
}

const arg = process.argv[2];
if (arg === 'plan') {
  const di = process.argv.indexOf('--days');
  plan(di > -1 ? parseInt(process.argv[di + 1], 10) || 30 : 30);
} else {
  build();
}

